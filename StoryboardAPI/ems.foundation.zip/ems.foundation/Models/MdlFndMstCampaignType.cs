﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ems.foundation.Models
{
    public class result
    {
        public bool status { get; set; }
        public string message { get; set; }
    }
    public class MdlFndMstCampaignTypeMaster : result

    {
        public string campaigntype_gid { get; set; }
        public string campaigntype_name { get; set; }
        public string campaigntype_code { get; set; }
        public string lms_code { get; set; }
        public string bureau_code { get; set; }
        public string created_date { get; set; }
        public string created_by { get; set; }
        public string updated_date { get; set; }
        public string updated_by { get; set; }
        public string remarks { get; set; }
        public string Status { get; set; }
        public char rbo_status { get; set; }
        public List<campaigntype_list> campaigntype_list { get; set; }
        public List<inactivecampaigntype_list> inactivecampaigntype_list { get; set; }

    }
    public class campaigntype_list : result
    {
        public string campaigntype_gid { get; set; }
        public string campaigntype_name { get; set; }
        public string created_date { get; set; }
        public string created_by { get; set; }
        public string updated_date { get; set; }
        public string updated_by { get; set; }
        public string remarks { get; set; }
        public string Status { get; set; }
        public char rbo_status { get; set; }
        public string status { get; set; }
        public string campaigntype_code { get; set; }
        public string lms_code { get; set; }
        public string bureau_code { get; set; }
    }
    public class inactivecampaigntype_list
    {
        public string remarks { get; set; }
        public string updated_by { get; set; }
        public string updated_date { get; set; }
    }
}