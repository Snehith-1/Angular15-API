﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Odbc;
using ems.utilities.Functions;
using ems.foundation.Models;
using System.Net.Mail;
using System.Net;
using System.Configuration;
using System.Web;
using System.IO;


namespace ems.foundation.DataAccess
{
    public class DaFndMstQuestionnarie
    {
        dbconn objdbconn = new dbconn();
        cmnfunctions objcmnfunctions = new cmnfunctions();
        DataTable dt_datatable;
        OdbcDataReader objODBCDatareader, objODBCDatareader1, objODBCDatareader2;
        string msSQL, msGetGid, msGetGid1, lscampaigntype_value, lslms_code, lsbureau_code, lsremarks, lscampaigntype_code;
        int mnResult;
        public void DaGetCampaignType(Mdlcampaigntype objcampaigntype ,string employee_gid)
        {
            try
            {
              
                msSQL = "delete from fnd_mst_tquestionnarieanswer where status = 'Y' and created_by = '" + employee_gid + "'";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

                msSQL = " SELECT campaigntype_gid,campaigntype_name FROM fnd_mst_tcampaigntype where status !='N' ";

                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getcampaigntype_list = new List<campaigntype_list>();
                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {
                        getcampaigntype_list.Add(new campaigntype_list
                        {
                            campaigntype_gid = (dr_datarow["campaigntype_gid"].ToString()),
                            campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                        });
                    }
                    objcampaigntype.campaigntype_list = getcampaigntype_list;
                }
                dt_datatable.Dispose();

                objcampaigntype.status = true;
            }
            catch
            {
                objcampaigntype.status = false;
            }

        }
        public void DaQuestionnarieEdit(string Questionnarie_gid, Questionnarie_list values)
        {
            try
            {
                msSQL = " select a.Questionnarie_gid, a.questionnarieanswer_gid, a.questionnarie_name,a.campaigntype_gid,e.categorytype_name, " +
                    " a.questionnarie_type, a.questionnarie_answer, a.importance,a.status,a.remarks,d.campaigntype_name, a.categorytype_gid " +
                    "  from fnd_mst_tquestionnarie a" +
                     " left join fnd_mst_tcampaigntype d on d.campaigntype_gid = a.campaigntype_gid "  +
                     " left join fnd_mst_tcategorytype e on e.categorytype_gid = a.categorytype_gid " +
                     " where a.Questionnarie_gid='" + Questionnarie_gid + "'";
                objODBCDatareader = objdbconn.GetDataReader(msSQL);
                if (objODBCDatareader.HasRows == true)
                {
                    values.Questionnarie_gid = objODBCDatareader["Questionnarie_gid"].ToString();
                    values.categorytype_gid = objODBCDatareader["categorytype_gid"].ToString();
                    values.categorytype_name = objODBCDatareader["categorytype_name"].ToString();
                    values.Questionnarie_name = objODBCDatareader["questionnarie_name"].ToString();
                    values.Questionnarie_type = objODBCDatareader["questionnarie_type"].ToString();
                    values.Campaigntype_gid = objODBCDatareader["campaigntype_gid"].ToString();
                    values.Campaigntype_name = objODBCDatareader["campaigntype_name"].ToString();
                    values.mandatory = objODBCDatareader["importance"].ToString();
                    values.remarks = objODBCDatareader["remarks"].ToString();

                }

                values.status = "true";
                values.message = "success";
                objODBCDatareader.Close();
            }
            catch
            {
                values.status = "false";
                values.message = "failure";
            }
        }
        
        public void DaGetQuestionnarie(MdlMstQuestionnarie values)
        {
            try
            {
                msSQL = " SELECT a.questionnarie_gid, a.campaigntype_gid, " +
                    "a.questionnarie_code, a.questionnarie_name, a.questionnarie_type, a.questionnarie_answer, a.questionnarieanswer_gid, a.importance," +
                    " a.lms_code, a.bureau_code,a.remarks, d.campaigntype_name,date_format(a.created_date,'%d-%m-%Y %h:%i %p') as created_date, " +
                        " concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by," +
                        " case when a.status='N' then 'Inactive' else 'Active' end as status" +
                        " FROM fnd_mst_tquestionnarie a" +
                        " left join fnd_mst_tcampaigntype d on d.campaigntype_gid = a.campaigntype_gid " +
                        " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
                        " left join adm_mst_tuser c on c.user_gid = b.user_gid order by a.questionnarie_gid desc ";
                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getQuestionnarie_list = new List<Questionnarie_list>();
                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {
                        getQuestionnarie_list.Add(new Questionnarie_list
                        {
                            Questionnarie_gid  = (dr_datarow["questionnarie_gid"].ToString()),
                            Campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                            Questionnarie_type = (dr_datarow["questionnarie_type"].ToString()),
                            Questionnarie_name  = (dr_datarow["questionnarie_name"].ToString()),
                            mandatory = (dr_datarow["importance"].ToString()),
                            lms_code = (dr_datarow["lms_code"].ToString()),
                            bureau_code = (dr_datarow["bureau_code"].ToString()),
                            remarks = (dr_datarow["remarks"].ToString()),
                            created_by = (dr_datarow["created_by"].ToString()),
                            created_date = (dr_datarow["created_date"].ToString()),
                            status = (dr_datarow["status"].ToString()),
                        });
                    }
                    values.Questionnarie_list  = getQuestionnarie_list;
                }
                dt_datatable.Dispose();
                values.status = true;
            }
            catch
            {
                values.status = false;
            }
        }
        public bool DaEditPostAnswerDesc(MdlMstQuestionnarie values, string employee_gid)
        {
          
            msGetGid = objcmnfunctions.GetMasterGID("FCQA");
            msSQL = " insert into fnd_mst_tquestionnarieanswer(" +

                    " questionnarieanswer_gid," +
                    " campaigntype_gid," +
                    " questionnarie_gid," +
                    " questionnarie_type," +
                    " questionnarie_answer," +
                    " status, " +
                    " created_by " +
                    " )" +
                    " values(" +
                    "'" + msGetGid + "'," +
                    "'" + values.Campaigntype_gid + "'," +
                    "'" + values.Questionnarie_gid + "'," +
                    "'" + values.Questionnarie_type + "'," +
                    "'" + values.answer_desc + "'," +
                    "'Y', " +
                    "'" + employee_gid + "'" +
                    " )";
            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

            if (mnResult != 0)
            {

                values.status = true;
                values.message = "Answer description Added Successfully";
                values.Questionnarie_gid = values.Questionnarie_gid;
                objdbconn.CloseConn();
                return true;
            }
            else
            {
                values.status = true;
                values.message = "Error Occured While Adding Answer description";
                objdbconn.CloseConn();
                return false;
            }
        }
        public bool DaPostAnswerDesc(MdlMstQuestionnarie values, string employee_gid)
        {
            msSQL = "select questionnarie_gid from fnd_mst_tquestionnarieanswer where status = 'Y' and created_by = '" + employee_gid + "' ";
            objODBCDatareader = objdbconn.GetDataReader(msSQL);
            if (objODBCDatareader.HasRows == true)
            {
                values.Questionnarie_gid = objODBCDatareader["questionnarie_gid"].ToString();
               
            }
            else
            {
                values.Questionnarie_gid = objcmnfunctions.GetMasterGID("FCQM");
            }
           
            msGetGid = objcmnfunctions.GetMasterGID("FCQA");
            msSQL = " insert into fnd_mst_tquestionnarieanswer(" +

                    " questionnarieanswer_gid," +
                    " campaigntype_gid," +
                    " questionnarie_gid," +
                    " questionnarie_type," +
                    " questionnarie_answer," +
                    " status, " +
                    " created_by " +
                    " )" +
                    " values(" +
                    "'" + msGetGid + "'," +
                    "'" + values.Campaigntype_gid + "'," +
                    "'" + values.Questionnarie_gid + "'," +
                    "'" + values.Questionnarie_type + "'," +
                    "'" + values.answer_desc + "'," +
                    "'Y', " +
                    "'" + employee_gid + "'" +
                    " )";
            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

            if (mnResult != 0)
            {

                values.status = true;
                values.message = "Answer description Added Successfully";
                values.Questionnarie_gid = values.Questionnarie_gid;
                objdbconn.CloseConn();
                return true;
            }
            else
            {
                values.status = true;
                values.message = "Error Occured While Adding Answer description";
                objdbconn.CloseConn();
                return false;
            }
        }

        public void DaGetAnswerDesc(questionnarieanswer_list values,string employee_gid,string Questionnarie_gid)
        {
            msSQL = "select questionnarieanswer_gid, campaigntype_gid, questionnarie_gid, questionnarie_type, questionnarie_answer " +
                    "from fnd_mst_tquestionnarieanswer where created_by = '" + employee_gid + "' and status = 'Y' " +
                    " and questionnarie_gid = '"+ Questionnarie_gid + "'";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var questionnarieanswer_list = new List<questionnarieanswer_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    questionnarieanswer_list.Add(new questionnarieanswer_list
                    {
                        questionnarieanswer_gid = (dr_datarow["questionnarieanswer_gid"].ToString()),
                        questionnarie_type = (dr_datarow["questionnarie_type"].ToString()),
                        questionnarie_answer = (dr_datarow["questionnarie_answer"].ToString()),
                        
                    });
                }
                values.questionnarieanswerlist = questionnarieanswer_list;
            }
            dt_datatable.Dispose();
        }
        public void DaGeteditAnswerDesc(questionnarieanswer_list values, string employee_gid, string Questionnarie_gid)
        {
            msSQL = "select questionnarieanswer_gid, campaigntype_gid, questionnarie_gid, questionnarie_type, questionnarie_answer " +
                    "from fnd_mst_tquestionnarieanswer where created_by = '" + employee_gid + "'  " +
                    " and questionnarie_gid = '" + Questionnarie_gid + "'";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var questionnarieanswer_list = new List<questionnarieanswer_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    questionnarieanswer_list.Add(new questionnarieanswer_list
                    {
                        questionnarieanswer_gid = (dr_datarow["questionnarieanswer_gid"].ToString()),
                        questionnarie_type = (dr_datarow["questionnarie_type"].ToString()),
                        questionnarie_answer = (dr_datarow["questionnarie_answer"].ToString()),

                    });
                }
                values.questionnarieanswerlist = questionnarieanswer_list;
            }
            dt_datatable.Dispose();
        }
        public void DaDeleteAnswerDesc(string questionnarieanswer_gid, MdlMstQuestionnarie values)
        {
            msSQL = "delete from fnd_mst_tquestionnarieanswer where questionnarieanswer_gid='" + questionnarieanswer_gid + "'";
            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            if (mnResult != 0)
            {

                values.message = "Answer description deleted successfully";
                values.status = true;
            }
            else
            {
                values.message = "Error Occured While Deleting the Answer description";
                values.status = false;

            }
        }
        public void DaCreateCampaignType(MdlMstQuestionnarie  values, string employee_gid)
        {
            string lsQuestionnarie_answer=string.Empty;

                if (values.lms_code == null || values.lms_code == "")
                {
                    lslms_code = "";
                }
                else
                {
                    lslms_code = values.lms_code.Replace("'", "");
                }
                if (values.bureau_code == null || values.bureau_code == "")
                {
                    lsbureau_code = "";
                }
                else
                {
                    lsbureau_code = values.bureau_code.Replace("'", "");
                }
                if (values.remarks == null || values.remarks == "")
                {
                    lsremarks = "";
                }
                else
                {
                    lsremarks = values.remarks.Replace("'", "");
                }

                if(values.Questionnarie_gid != null)
                {
                msGetGid = values.Questionnarie_gid;

                msSQL = " SELECT GROUP_CONCAT(questionnarie_answer SEPARATOR ', ') questionnarie_answer " +
                         " FROM fnd_mst_tquestionnarieanswer where questionnarie_gid =  '" + values.Questionnarie_gid + "'";
                objODBCDatareader = objdbconn.GetDataReader(msSQL);
                if (objODBCDatareader.HasRows == true)
                {
                    lsQuestionnarie_answer = objODBCDatareader["questionnarie_answer"].ToString();

                }

                
            }
                else
                {
                msGetGid = objcmnfunctions.GetMasterGID("FCQM");
                }


            msSQL = " insert into fnd_mst_tquestionnarie(" +
                        " questionnarie_gid," +
                        " campaigntype_gid," +
                        " questionnarie_name," +
                        " questionnarie_type," +
                        " questionnarie_answer," +
                        " importance," +
                        " lms_code," +
                        " bureau_code," +
                        " remarks," +
                        " created_by," +
                        " created_date,categorytype_gid)" +
                        " values(" +
                        "'" + msGetGid + "'," +
                        "'" + values.Campaigntype_gid + "'," +
                        "'" + values.Questionnarie_name  + "'," +
                        "'" + values.Questionnarie_type + "'," +
                        "'" + lsQuestionnarie_answer + "'," +
                        "'" + values.rbo_mandatory + "'," +
                        "'" + lslms_code + "'," +
                        "'" + lsbureau_code + "'," +
                        "'" + lsremarks + "'," +
                        "'" + employee_gid + "'," +
                        "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', " +
                         "'" + values.category_gid + "')";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
                if (mnResult != 0)
                {
                    values.status = true;
                    values.message = "Questionnarie Added Successfully";

                msSQL = "update fnd_mst_tquestionnarieanswer set status = 'N' where created_by='" + employee_gid + "'";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
               
                 }
                else
                {
                    values.status = false;
                    values.message = "Error Occurred While Adding";
                }
            }
        public void DaEditQuestionnarieSubmit(MdlMstQuestionnarie values, string employee_gid)
        {
            string lsQuestionnarie_answer = string.Empty;

            if (values.lms_code == null || values.lms_code == "")
            {
                lslms_code = "";
            }
            else
            {
                lslms_code = values.lms_code.Replace("'", "");
            }
            if (values.bureau_code == null || values.bureau_code == "")
            {
                lsbureau_code = "";
            }
            else
            {
                lsbureau_code = values.bureau_code.Replace("'", "");
            }
            if (values.remarks == null || values.remarks == "")
            {
                lsremarks = "";
            }
            else
            {
                lsremarks = values.remarks.Replace("'", "");
            }

            if (values.Questionnarie_gid != null)
            {
                msGetGid = values.Questionnarie_gid;

                msSQL = " SELECT GROUP_CONCAT(questionnarie_answer SEPARATOR ', ') questionnarie_answer " +
                         " FROM fnd_mst_tquestionnarieanswer where questionnarie_gid =  '" + values.Questionnarie_gid + "'";
                objODBCDatareader = objdbconn.GetDataReader(msSQL);
                if (objODBCDatareader.HasRows == true)
                {
                    lsQuestionnarie_answer = objODBCDatareader["questionnarie_answer"].ToString();

                }


            }
            else
            {
                msGetGid = objcmnfunctions.GetMasterGID("FCQM");
            }

            msSQL = " update fnd_mst_tquestionnarie set " +
                 " campaigntype_gid=  '" + values.Campaigntype_gid + "'," +
                  " categorytype_gid=  '" + values.categorytype_gid + "'," +
                        " questionnarie_name = '" + values.Questionnarie_name + "'," +
                        " questionnarie_type='" + values.Questionnarie_type + "'," +
                        " questionnarie_answer='" + lsQuestionnarie_answer + "'," +
                        " importance='" + values.rbo_mandatory + "'," +
                        " remarks='" + lsremarks + "' " +
                        " where questionnarie_gid = '" + values.Questionnarie_gid  + "'";

          
            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            if (mnResult != 0)
            {
                values.status = true;
                values.message = "Questionnarie Updated Successfully";

                msSQL = "update fnd_mst_tquestionnarieanswer set status = 'N' where questionnarie_gid = '" + values.Questionnarie_gid + "'";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

            }
            else
            {
                values.status = false;
                values.message = "Error Occurred While Adding";
            }
        }
        public void DaDeleteQuestionnarie(MdlMstQuestionnarie values, string Questionnarie_gid,string employee_gid)
        {


            msSQL = " select Questionnarie_name from fnd_mst_tquestionnarie where Questionnarie_gid='" + Questionnarie_gid + "'";
            lscampaigntype_value = objdbconn.GetExecuteScalar(msSQL);
            msSQL = " delete from fnd_mst_tquestionnarie where Questionnarie_gid='" + Questionnarie_gid + "'";
            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

            if (mnResult != 0)
            {
                values.status = true;
                values.message = "Questionnarie Deleted Successfully..!";
                msGetGid = objcmnfunctions.GetMasterGID("FCQD");
                msSQL = " insert into fnd_mst_tquestionnariedeletelog(" +
                         "questionnariedeletelog_gid, " +
                         "questionnarie_gid, " +
                         "master_name, " +
                         "master_value, " +
                         "deleted_by, " +
                         "deleted_date) " +
                         " values(" +
                         "'" + msGetGid + "'," +
                         "'" + Questionnarie_gid + "', " +
                         "'Questionnarie'," +
                         "'" + lscampaigntype_value + "'," +
                         "'" + employee_gid + "'," +
                         "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";

                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            }
            else
            {
                values.status = false;
                values.message = "Error Occured..!";
            }
        }
      

   

        public void DaInactiveQuestionnarie(MdlMstQuestionnarie values, string employee_gid)
        {
            msSQL = " update fnd_mst_tquestionnarie set status='" + values.rbo_status + "'" +
                    " where Questionnarie_gid='" + values.Questionnarie_gid + "' ";
            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

            if (mnResult != 0)
            {
                msGetGid = objcmnfunctions.GetMasterGID("FDIL");

                msSQL = " insert into fnd_mst_tquestionnarieinactivelog (" +
                      " questionnarieinactivelog_gid, " +
                      " Questionnarie_gid," +
                      " Questionnarie_name," +
                      " status," +
                      " remarks," +
                      " updated_by," +
                      " updated_date) " +
                      " values (" +
                      " '" + msGetGid + "'," +
                      " '" + values.Questionnarie_gid + "'," +
                      " '" + values.Questionnarie_name + "'," +
                      " '" + values.rbo_status + "'," +
                      " '" + values.remarks.Replace("'", "") + "'," +
                      " '" + employee_gid + "'," +
                      " '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
                if (values.rbo_status == 'N')
                {
                    values.status = true;
                    values.message = "Questionnarie Inactivated Successfully";
                }
                else
                {
                    values.status = true;
                    values.message = "Questionnarie Activated Successfully";
                }
            }
            else
            {
                values.status = false;
                values.message = "Error Occurred";
            }
        }
        
        public void DaQuestionnarieInactiveLogview(string Questionnarie_gid, MdlMstQuestionnarie values)
        {
            try
            {
                msSQL = " SELECT a.questionnarie_gid,date_format(a.updated_date,'%d-%m-%Y %h:%i %p') as updated_date, " +
                        " concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as updated_by," +
                        " case when a.status='N' then 'Inactive' else 'Active' end as Status, a.remarks" +
                        " FROM fnd_mst_tquestionnarieinactivelog a" +
                        " left join hrm_mst_temployee b on a.updated_by = b.employee_gid" +
                        " left join adm_mst_tuser c on c.user_gid = b.user_gid " +
                        " where a.questionnarie_gid ='" + Questionnarie_gid + "' order by a.questionnarieinactivelog_gid desc ";
                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getQuestionnarie_list = new List<Questionnarie_list>();
                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {
                        getQuestionnarie_list.Add(new Questionnarie_list
                        {
                            Questionnarie_gid = (dr_datarow["questionnarie_gid"].ToString()),
                            updated_by = (dr_datarow["updated_by"].ToString()),
                            updated_date = (dr_datarow["updated_date"].ToString()),
                            status = (dr_datarow["Status"].ToString()),
                            remarks = (dr_datarow["remarks"].ToString()),
                        });
                    }
                    values.Questionnarie_list = getQuestionnarie_list;
                }
                dt_datatable.Dispose();
                values.status = true;
            }
            catch
            {
                values.status = false;
            }
        }
    }




}
