﻿using ems.foundation.Models;
using ems.utilities.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Data.Odbc;
using System.Linq;
using System.Globalization;

using System.Text.RegularExpressions;
using System.Net.Mail;
using System.Web.Script.Serialization;
using System.Net;
using System.Web;
using System.IO;
//using OfficeOpenXml;

namespace ems.foundation.DataAccess
{
    public class DaFndTrnMyCampaignSummary
    {
        dbconn objdbconn = new dbconn();
        cmnfunctions objcmnfunctions = new cmnfunctions();
        DataTable dt_datatable;
        HttpPostedFile httpPostedFile;
        OdbcDataReader objODBCDatareader;
        string msSQL, msGetGid, msGettaguser2audit_gid, lsquery_status, lssession_user, count, lsauditdepartment_value, lscapture_yesscore, lscapture_noscore, lscapture_partialscore, lscapture_nascore, lscapture_totalscore, msGetaudituniqueno, lsdue_date, lsreport_date, lsperiodfrom_date, lsauditperiod_to, lsauditname_value;
        int mnResult;

    

        public void DaGetCampaignSummary(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {
            
        
                msSQL = "select a.campaign_gid,a.campaign_code,a.campaign_name,date_format(a.created_date, '%d-%m-%Y %h:%i %p') as created_date," +
                 "  date_format(a.assesment_date,'%d-%m-%Y %h:%i %p') as assesment_date , case when a.status='N' then 'Inactive' else 'Active' end as status, concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by," +
                 " a.status_flag,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_manager,d.campaigntype_name,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_approver  " +
                 " from fnd_trn_tcampaign  a" +
                 " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
                " left join fnd_mst_tcampaigntype d on a.campaigntype_gid = d.campaigntype_gid" +
                " left join adm_mst_tuser c on c.user_gid = b.user_gid   " + 
                "  left join fnd_mst_tcampaignapproving2employee e on e.campaign_gid = a.campaign_gid " +
                " and e.employee_gid = '"+ employee_gid +"' " +
                "  where (a.campaign_status = 'Approved' or a.campaign_status = 'Pending for Final Approval' or "+
                " a.campaign_status = 'WIP')" +
                " and e.employee_gid = '" + employee_gid + "'" +
                " order by campaign_gid desc";

                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getmycampaign_list = new List<mycampaign_list>();
                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {
                        getmycampaign_list.Add(new mycampaign_list
                        {
                            campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                            campaign_code = (dr_datarow["campaign_code"].ToString()),
                            campaign_name = (dr_datarow["campaign_name"].ToString()),
                            created_date = (dr_datarow["created_date"].ToString()),
                            created_by = (dr_datarow["created_by"].ToString()),
                            assesment_date = (dr_datarow["assesment_date"].ToString()),
                            campaign_approver = (dr_datarow["campaign_approver"].ToString()),
                            campaign_manager = (dr_datarow["campaign_manager"].ToString()),
                            status = (dr_datarow["status"].ToString()),
                            campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),               
                            status_flag = (dr_datarow["status_flag"].ToString()),

                        });
                    }
                    values.mycampaign_list = getmycampaign_list;
                }
                dt_datatable.Dispose();                       
          
        }



        public void DaGetCampaignSummaryPending(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {


            msSQL = "select a.campaign_gid,a.campaign_code,a.campaign_name,date_format(a.created_date, '%d-%m-%Y %h:%i %p') as created_date," +
             "  date_format(a.assesment_date,'%d-%m-%Y %h:%i %p') as assesment_date , case when a.status='N' then 'Inactive' else 'Active' end as status, concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by," +
             " a.status_flag,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_manager,d.campaigntype_name,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_approver  " +
             " from fnd_trn_tcampaign  a" +
             " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
            " left join fnd_mst_tcampaigntype d on a.campaigntype_gid = d.campaigntype_gid" +
            " left join adm_mst_tuser c on c.user_gid = b.user_gid    where a.campaign_manager='" + employee_gid + "' and a.campaign_status = 'Pending'  order by campaign_gid desc";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getmycampaign_list = new List<mycampaign_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getmycampaign_list.Add(new mycampaign_list
                    {
                        campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                        campaign_code = (dr_datarow["campaign_code"].ToString()),
                        campaign_name = (dr_datarow["campaign_name"].ToString()),
                        created_date = (dr_datarow["created_date"].ToString()),
                        created_by = (dr_datarow["created_by"].ToString()),
                        assesment_date = (dr_datarow["assesment_date"].ToString()),
                        campaign_approver = (dr_datarow["campaign_approver"].ToString()),
                        campaign_manager = (dr_datarow["campaign_manager"].ToString()),
                        status = (dr_datarow["status"].ToString()),
                        campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                        status_flag = (dr_datarow["status_flag"].ToString()),

                    });
                }
                values.mycampaign_list = getmycampaign_list;
            }
            dt_datatable.Dispose();

        }

        public void DaGetCampaignSummaryApproved(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {


            msSQL = "select a.campaign_gid,a.campaign_code,a.campaign_name,date_format(a.created_date, '%d-%m-%Y %h:%i %p') as created_date," +
             "  date_format(a.assesment_date,'%d-%m-%Y %h:%i %p') as assesment_date , case when a.status='N' then 'Inactive' else 'Active' end as status, concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by," +
             " a.status_flag,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_manager,d.campaigntype_name,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_approver  " +
             " from fnd_trn_tcampaign  a" +
             " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
            " left join fnd_mst_tcampaigntype d on a.campaigntype_gid = d.campaigntype_gid" +
            " left join adm_mst_tuser c on c.user_gid = b.user_gid    where a.campaign_manager='" + employee_gid + "' and a.campaign_status = 'Approved'  order by campaign_gid desc";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getmycampaign_list = new List<mycampaign_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getmycampaign_list.Add(new mycampaign_list
                    {
                        campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                        campaign_code = (dr_datarow["campaign_code"].ToString()),
                        campaign_name = (dr_datarow["campaign_name"].ToString()),
                        created_date = (dr_datarow["created_date"].ToString()),
                        created_by = (dr_datarow["created_by"].ToString()),
                        assesment_date = (dr_datarow["assesment_date"].ToString()),
                        campaign_approver = (dr_datarow["campaign_approver"].ToString()),
                        campaign_manager = (dr_datarow["campaign_manager"].ToString()),
                        status = (dr_datarow["status"].ToString()),
                        campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                        status_flag = (dr_datarow["status_flag"].ToString()),

                    });
                }
                values.mycampaign_list = getmycampaign_list;
            }
            dt_datatable.Dispose();

        }
        public void DaAtmTrnSamplingimportexcel(System.Web.HttpRequest httpRequest, string employee_gid, result objResult, MdlFndTrnMyCampaignSummary values)
        {
            try
            {
                string lscompany_code;
                int insertCount = 0;
                HttpFileCollection httpFileCollection;
                DataTable dt = null;
                string lspath, lsfilePath, lssampleaudit_gid;
                string lsaudit_gid = httpRequest.Form["auditcreation_gid"];

                msSQL = " select company_code from adm_mst_tcompany";
                lscompany_code = objdbconn.GetExecuteScalar(msSQL);

                // Create Directory
                lsfilePath = HttpContext.Current.Server.MapPath("../../../erp_documents" + "/" + lscompany_code + "/Audit/SampleImportExcelDocument/" + DateTime.Now.Year + "/" + DateTime.Now.Month);

                if ((!System.IO.Directory.Exists(lsfilePath)))
                    System.IO.Directory.CreateDirectory(lsfilePath);


                httpFileCollection = httpRequest.Files;
                for (int i = 0; i < httpFileCollection.Count; i++)
                {
                    httpPostedFile = httpFileCollection[i];
                }
                string FileExtension = httpPostedFile.FileName;

                string msdocument_gid = objcmnfunctions.GetMasterGID("UPLF");
                string lsfile_gid = msdocument_gid;
                FileExtension = Path.GetExtension(FileExtension).ToLower();
                lsfile_gid = lsfile_gid + FileExtension;

                Stream ls_readStream;
                ls_readStream = httpPostedFile.InputStream;
                MemoryStream ms = new MemoryStream();
                ls_readStream.CopyTo(ms);

                //path creation        
                lspath = lsfilePath + "/";
                FileStream file = new FileStream(lspath + lsfile_gid, FileMode.Create, FileAccess.Write);
                ms.WriteTo(file);

                int rowCount;
                int columnCount;
                string excelRange,endRange, lssample_name, msGetGid1;
                try
                {
                    ////using (ExcelPackage xlPackage = new ExcelPackage(ms))
                    ////{
                    ////    ExcelWorksheet worksheet = xlPackage.Workbook.Worksheets[1];
                    ////    rowCount = worksheet.Dimension.End.Row;
                    ////    columnCount = worksheet.Dimension.End.Column;
                    ////    endRange = worksheet.Dimension.End.Address;
                    ////}
                    ////file.Close();
                    ////ms.Close();

                    ////objcmnfunctions.uploadFile(lspath, lsfile_gid);
                }
                catch (Exception ex)
                {
                    objResult.status = false;
                    objResult.message = ex.ToString();
                    return;
                }


                //Excel To DataTable


                try
                {
                //    lsfilePath = @"" + lsfilePath.Replace("/", "\\") + "\\" + lsfile_gid + "";
                //    excelRange = "A1:" + endRange + rowCount.ToString();
                //    dt = objcmnfunctions.ExcelToDataTable(lsfilePath, excelRange);
                //    dt = dt.Rows.Cast<DataRow>().Where(r => string.Join("", r.ItemArray).Trim() != string.Empty).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    objResult.status = false;
                    objResult.message = ex.ToString();
                    return;
                }
                Nullable<DateTime> ldcodecreation_date;

                string[] columnNames = dt.Columns.Cast<DataColumn>()
                                 .Select(x => x.ColumnName)
                                 .ToArray();
                string Header_name = "", Header_value = "";
                foreach (DataRow row in dt.Rows)
                {
                    lssample_name = row["*Sample Name"].ToString();

                    msGetGid = objcmnfunctions.GetMasterGID("AUSI");
                    msSQL = " insert into atm_trn_tsampleimport(" +
                    " sampleimport_gid," +
                    " auditcreation_gid," +
                    " sample_name, " +
                    " created_by," +
                    " created_date)" +
                    " values(" +
                    "'" + msGetGid + "'," +
                    "'" + lsaudit_gid + "'," +
                    "'" + lssample_name + "'," +
                    "'" + employee_gid + "'," +
                    "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                    mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
                    if (mnResult == 1)
                    {
                        foreach (var i in columnNames)
                        {
                            Header_name = i.Trim();
                            Header_name = Header_name.Replace("*", "");
                            Header_name = Header_name.Replace(" ", "_");

                            Header_value = row[i].ToString();
                            msGetGid1 = objcmnfunctions.GetMasterGID("SIDE");
                            msSQL = " insert into atm_trn_tsampleexcelimport(" +
                                    " excelimport_gid," +
                                    " sampleimport_gid, " +
                                    " auditcreation_gid, " +
                                    " header_names," +
                                    " header_values," +
                                    " created_by," +
                                    " created_date)" +
                                    " values(" +
                                    "'" + msGetGid1 + "'," +
                                    "'" + msGetGid + "'," +
                                    "'" + lsaudit_gid + "'," +
                                    "'" + Header_name + "'," +
                                    "'" + Header_value + "'," +
                                    "'" + employee_gid + "'," +
                                    "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

                        }
                    }
                    insertCount++;
                }

                if (mnResult != 0)
                {

                    objResult.status = true;
                    objResult.message = insertCount.ToString() + " Of " + dt.Rows.Count.ToString() + " Records Uploaded Successfully";
                }
                else
                {
                    objResult.status = false;
                    objResult.message = "Error occured in uploading Excel Sheet Details";
                }

                dt.Dispose();

            }


            catch (Exception ex)
            {
                objResult.status = false;
                objResult.message = ex.ToString();
            }

        }
        public void DaGetCampaignApprovalpending(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {

            msSQL = "select a.campaign_gid,a.campaign_code,a.campaign_name,date_format(a.created_date, '%d-%m-%Y %h:%i %p') as created_date," +
             "  date_format(a.assesment_date,'%d-%m-%Y %h:%i %p') as assesment_date , case when a.status='N' then 'Inactive' else 'Active' end as status, concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by," +
             " a.status_flag,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_manager,d.campaigntype_name,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_approver  " +
             " from fnd_trn_tcampaign  a" +
             " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
             " left join fnd_mst_tcampaigntype d on a.campaigntype_gid = d.campaigntype_gid" +
             " left join adm_mst_tuser c on c.user_gid = b.user_gid    where " +
             " a.campaign_approver='" + employee_gid + "' and  " +
             " a.campaign_status = 'Pending for Final Approval'" +
             "order by campaign_gid desc";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getmycampaign_list = new List<mycampaign_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getmycampaign_list.Add(new mycampaign_list
                    {
                        campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                        campaign_code = (dr_datarow["campaign_code"].ToString()),
                        campaign_name = (dr_datarow["campaign_name"].ToString()),
                        created_date = (dr_datarow["created_date"].ToString()),
                        created_by = (dr_datarow["created_by"].ToString()),
                        assesment_date = (dr_datarow["assesment_date"].ToString()),
                        campaign_approver = (dr_datarow["campaign_approver"].ToString()),
                        campaign_manager = (dr_datarow["campaign_manager"].ToString()),
                        status = (dr_datarow["status"].ToString()),
                        campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                        status_flag = (dr_datarow["status_flag"].ToString()),

                    });
                }
                values.mycampaign_list = getmycampaign_list;
            }
            dt_datatable.Dispose();

        }
        public bool DaMyCampaignSubmit(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {
           

            msSQL = " insert into fnd_trn_tmycampaignsingle ( " +
                    " campaign_gid,"+
                    " questionnarie_gid, questionnarie_name,"+
                    " questionnarie_type, questionnarie_answer,"+
                    " form_type, status,mycampaign_status, created_by,created_date" +
                   "  )" +
                   " values(" +
                   "'" + values.campaign_gid + "'," +
                   "'" + values.questionnarie_gid + "'," +
                   "'" + values.questionnarie_name + "'," +
                   "'" + values.questionnarie_type + "'," +
                   "'" + values.questionnarie_answer + "'," +
                   "'" + values.form_type + "'," +
                   "'Pending' ," +
                   "'Pending for Approval' ," +
                   "'" + employee_gid + "'," +
                    "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";

            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            if (mnResult != 0)
            {


                values.status = true;
                values.message = "Single Form Added Successfully";


                return true;
            }
            else
            {
                values.status = false;
                values.message = "Error Occured While saving MyCampaign";
                return false;
            }

        }
        public bool DaMyCampaignUpdate(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {

            msSQL = "update fnd_trn_tmycampaignsingle set " +
                    "questionnarie_answer =  '" + values.questionnarie_answer + "'," +
                    "updated_by = '" + employee_gid + "'," +
                    "updated_date = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'" +
                    "where mycampaignsingle_gid = '" + values.mycampaignsingle_gid + "' " +
                    "and campaign_gid= '" + values.campaign_gid + "'" ;
            

            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            if (mnResult != 0)
            {


                values.status = true;
                values.message = "Single Form updated Successfully";


                return true;
            }
            else
            {
                values.status = false;
                values.message = "Error Occured While updating Single form";
                return false;
            }

        }
        public bool DaMyCampaignMultipleUpdate(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {

            msSQL = "update fnd_trn_tmycampaignmultiple set " +
                    "header_values =  '" + values.questionnarie_answer + "'," +
                    "updated_by = '" + employee_gid + "'," +
                    "updated_date = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'" +
                    "where mycampaignmultiple_gid = '" + values.mycampaignmultiple_gid + "' " +
                    "and campaign_gid= '" + values.campaign_gid + "'";


            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            if (mnResult != 0)
            {


                values.status = true;
                values.message = "Single Form updated Successfully";


                return true;
            }
            else
            {
                values.status = false;
                values.message = "Error Occured While updating Single form";
                return false;
            }

        }
        public void DaGetCampaignDetails(MdlTrnCampaign values, string campaign_gid)
        {



            try
            {
                msSQL = " select c.campaign_gid,a.campaigndtl_gid,a.questionnarie_gid, " +
                        "campaign_code,d.campaigntype_name,c.start_date,c.end_date,c.assesment_date,e.customer_name," +
                        "c.contact_name, c.contact_mobile, c.contact_email," +
                        " c.campaign_name,a.questionnarie_type,a.questionnarie_answer, " +
                        " a.questionnarie_name ,a.importance,f.questionnarie_answer as singleform_answer  from fnd_trn_tcampaigndtl a " +
                        " left join fnd_mst_tquestionnarie b on a.questionnarie_gid = b.questionnarie_gid " +
                        " left join fnd_trn_tcampaign c on c.campaign_gid = a.campaign_gid " +
                        " left join fnd_mst_tcampaigntype d on d.campaigntype_gid = c.campaigntype_gid " +
                         " left join fnd_mst_tcustomer e on e.customer_gid = c.customer_gid " +
                         " left join fnd_trn_tmycampaignsingle f on f.questionnarie_gid = a.questionnarie_gid and f.campaign_gid =a.campaign_gid " +
                        " where a.campaign_gid='" + campaign_gid + "' and a.form_type = 'S'";
                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getcampaign_details = new List<campaign_details>();

                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {


                        var getanswerdesc_details = new List<answerdesc_list>();
                        if ((dr_datarow["questionnarie_type"].ToString() == "List"))
                        {
                            string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                            string[] ansdesc_sList = answerdesc_list.Split(',');

                            foreach (string author in ansdesc_sList)
                            {
                                getanswerdesc_details.Add(new answerdesc_list
                                {
                                    name = author,

                                });
                            }

                        }
                        if ((dr_datarow["questionnarie_type"].ToString() == "Radio_Button"))
                        {
                            string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                            string[] ansdesc_sList = answerdesc_list.Split(',');

                            foreach (string author in ansdesc_sList)
                            {
                                getanswerdesc_details.Add(new answerdesc_list
                                {
                                    id = (dr_datarow["questionnarie_gid"].ToString()),
                                    name = author,

                                });
                            }

                        }
                        getcampaign_details.Add(new campaign_details
                        {
                            campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                            campaigndtl_gid = (dr_datarow["campaigndtl_gid"].ToString()),
                            questionnarie_gid = (dr_datarow["questionnarie_gid"].ToString()),
                            answer_type = (dr_datarow["questionnarie_type"].ToString()),
                            answer_desc = (dr_datarow["questionnarie_answer"].ToString()),
                            campaign_name = (dr_datarow["campaign_name"].ToString()),
                            question = (dr_datarow["questionnarie_name"].ToString()),
                            campaignrefno = dr_datarow["campaign_code"].ToString(),
                            campaign_type = dr_datarow["campaigntype_name"].ToString(),
                            customer_name = dr_datarow["customer_name"].ToString(),
                            contactperson_fn = dr_datarow["contact_name"].ToString(),
                            contactperson_mobile = dr_datarow["contact_mobile"].ToString(),
                            contactperson_email = dr_datarow["contact_email"].ToString(),
                            start_date = dr_datarow["start_date"].ToString(),
                            end_date = dr_datarow["end_date"].ToString(),
                            assesment_date = dr_datarow["assesment_date"].ToString(),
                            importance = (dr_datarow["importance"].ToString()),
                            singleform_answer = (dr_datarow["singleform_answer"].ToString()),
                            answerdesc_list = getanswerdesc_details,
                        });

                    }
                    values.campaign_details = getcampaign_details;




                }
                dt_datatable.Dispose();
                values.status = true;
            }
            catch (Exception ex)
            {
                values.status = false;
            }
        }
        public void MyCampaignApprovedSubmit(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {
            try
            {


                msSQL = " update fnd_trn_tcampaign set mycampaignapproval_remarks = '" + values.mycampaignapproval_remarks + "'" +
                        " ,campaign_status = 'Mycampaign closed' " +
                        " where campaign_gid='" + values.campaign_gid + "' ";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);



                values.message = "My Campaign Form Approved";
                values.status = true;
            }
            catch (Exception ex)
            {
                values.status = false;
            }
        }
        public void MyCampaignRejectSubmit(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {
            try
            {


                msSQL = " update fnd_trn_tcampaign set mycampaignapproval_remarks = '" + values.mycampaignapproval_remarks + "'" +
                        " ,campaign_status = 'Mycampaign rejected' " +
                        " where campaign_gid='" + values.campaign_gid + "' ";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);



                values.message = "My Campaign Form Rejected";
                values.status = true;
            }
            catch (Exception ex)
            {
                values.status = false;
            }
        }
        public void CampaignFinalSubmit(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {
            try
            {

            
                msSQL = " update fnd_mst_tcampaignapproving2employee set mycampaign_status = 'Pending for Final Approval'" +
                        " where campaign_gid='" + values.campaign_gid + "' and employee_gid = '" + employee_gid + "'";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

                msSQL = " update fnd_trn_tcampaign set campaign_status = 'WIP'" +
                       " where campaign_gid='" + values.campaign_gid + "' ";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);

                int lsCompleted_count=0;
                int lsActual_count=0;
               

                msSQL = " select count(*) as completed_count from fnd_mst_tcampaignapproving2employee where campaign_gid = '" + values.campaign_gid + "' " +
                          "  and mycampaign_status = 'Pending for Final Approval' ";
                objODBCDatareader = objdbconn.GetDataReader(msSQL);
                if (objODBCDatareader.HasRows == true)
                {
                    lsCompleted_count = Convert.ToInt16(objODBCDatareader["completed_count"].ToString());
                }
                objODBCDatareader.Close();
                msSQL = "  select count(*) as actual_count from fnd_mst_tcampaignapproving2employee where campaign_gid = '" + values.campaign_gid + "' ";
                objODBCDatareader = objdbconn.GetDataReader(msSQL);
                if (objODBCDatareader.HasRows == true)
                {
                    lsActual_count = Convert.ToInt16(objODBCDatareader["actual_count"].ToString());
                }
                objODBCDatareader.Close();
                if(lsCompleted_count == lsActual_count)
                {
                    msSQL = "update fnd_trn_tcampaign set campaign_status = 'Pending for Final Approval' where campaign_gid='" + values.campaign_gid + "'";
                    mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
                }

                values.message = "My Campaign Form Submitted Successfully";
                values.status = true;
            }
            catch (Exception ex)
            {
                values.status = false;
            }
        }
        public void GetCampaignMultipleDetails(MdlTrnCampaign values, string campaign_gid)
        {



            try
            {
                msSQL = " select c.campaign_gid,a.campaigndtl_gid,a.questionnarie_gid, " +
                    "campaign_code,d.campaigntype_name,c.start_date,c.end_date,c.assesment_date,e.customer_name," +
                    "c.contact_name, c.contact_mobile, c.contact_email," +
                        " c.campaign_name,a.questionnarie_type,a.questionnarie_answer, " +
                        " a.questionnarie_name ,a.importance from fnd_trn_tcampaigndtl a " +
                        " left join fnd_mst_tquestionnarie b on a.questionnarie_gid = b.questionnarie_gid " +
                        " left join fnd_trn_tcampaign c on c.campaign_gid = a.campaign_gid " +
                        " left join fnd_mst_tcampaigntype d on d.campaigntype_gid = c.campaigntype_gid " +
                         " left join fnd_mst_tcustomer e on e.customer_gid = c.campaigntype_gid " +
                        " where a.campaign_gid='" + campaign_gid + "' and a.form_type = 'M'";
                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getmulticampaign_details = new List<multi_campaign_details>();

                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {


                        var getmultianswerdesc_details = new List<multi_answerdesc_list>();
                        if ((dr_datarow["questionnarie_type"].ToString() == "List"))
                        {
                            string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                            string[] ansdesc_sList = answerdesc_list.Split(',');

                            foreach (string author in ansdesc_sList)
                            {
                                getmultianswerdesc_details.Add(new multi_answerdesc_list
                                {
                                    name = author,

                                });
                            }

                        }
                        if ((dr_datarow["questionnarie_type"].ToString() == "Radio_Button"))
                        {
                            string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                            string[] ansdesc_sList = answerdesc_list.Split(',');

                            foreach (string author in ansdesc_sList)
                            {
                                getmultianswerdesc_details.Add(new multi_answerdesc_list
                                {
                                    id = (dr_datarow["questionnarie_gid"].ToString()),
                                    name = author,

                                });
                            }

                        }
                        getmulticampaign_details.Add(new multi_campaign_details
                        {
                            campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                            campaigndtl_gid = (dr_datarow["campaigndtl_gid"].ToString()),
                            questionnarie_gid = (dr_datarow["questionnarie_gid"].ToString()),
                            answer_type = (dr_datarow["questionnarie_type"].ToString()),
                            answer_desc = (dr_datarow["questionnarie_answer"].ToString()),
                            campaign_name = (dr_datarow["campaign_name"].ToString()),
                            question = (dr_datarow["questionnarie_name"].ToString()),
                            campaignrefno = dr_datarow["campaign_code"].ToString(),
                            campaign_type = dr_datarow["campaigntype_name"].ToString(),
                            customer_name = dr_datarow["customer_name"].ToString(),
                            contactperson_fn = dr_datarow["contact_name"].ToString(),
                            contactperson_mobile = dr_datarow["contact_mobile"].ToString(),
                            contactperson_email = dr_datarow["contact_email"].ToString(),
                            start_date = dr_datarow["start_date"].ToString(),
                            end_date = dr_datarow["end_date"].ToString(),
                            assesment_date = dr_datarow["assesment_date"].ToString(),
                            importance = (dr_datarow["importance"].ToString()),
                            multi_answerdesc_list = getmultianswerdesc_details,
                        });

                    }
                    values.multi_campaign_details = getmulticampaign_details;




                }
                dt_datatable.Dispose();
                values.status = true;
            }
            catch (Exception ex)
            {
                values.status = false;
            }
        }
        public void DaGetCampaignApprovalclose(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {


            msSQL = "select a.campaign_gid,a.campaign_code,a.campaign_name,date_format(a.created_date, '%d-%m-%Y %h:%i %p') as created_date," +
             "  date_format(a.assesment_date,'%d-%m-%Y %h:%i %p') as assesment_date , case when a.status='N' then 'Inactive' else 'Active' end as status, concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by," +
             " a.status_flag,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_manager,d.campaigntype_name,concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as campaign_approver  " +
             " from fnd_trn_tcampaign  a" +
             " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
            " left join fnd_mst_tcampaigntype d on a.campaigntype_gid = d.campaigntype_gid" +
            " left join adm_mst_tuser c on c.user_gid = b.user_gid    where " +
           // " a.campaign_manager='" + employee_gid + "' and " +
            "  a.campaign_status = 'Mycampaign closed'  order by campaign_gid desc";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getmycampaign_list = new List<mycampaign_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getmycampaign_list.Add(new mycampaign_list
                    {
                        campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                        campaign_code = (dr_datarow["campaign_code"].ToString()),
                        campaign_name = (dr_datarow["campaign_name"].ToString()),
                        created_date = (dr_datarow["created_date"].ToString()),
                        created_by = (dr_datarow["created_by"].ToString()),
                        assesment_date = (dr_datarow["assesment_date"].ToString()),
                        campaign_approver = (dr_datarow["campaign_approver"].ToString()),
                        campaign_manager = (dr_datarow["campaign_manager"].ToString()),
                        status = (dr_datarow["status"].ToString()),
                        campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                        status_flag = (dr_datarow["status_flag"].ToString()),

                    });
                }
                values.mycampaign_list = getmycampaign_list;
            }
            dt_datatable.Dispose();

        }
        public void DaGetSingleCampaignSummary(string employee_gid, MdlTrnCampaign values, string campaign_gid)
        {
            msSQL = " select a.campaign_gid,a.campaign_code,a.campaign_name," +
                    " date_format(a.created_date,'%d-%m-%Y %h:%i %p') as created_date," +
                    " case when a.status='N' then 'Inactive' else 'Active' end as status," +
                    " case when a.campaign_status='NA' then 'Not yet Completed' when a.campaign_status='Pending' " +
                    " then 'Approval Pending' else 'Completed' end as campaign_status," +
                    " a.status_flag,b.customer_name ," +
                    " concat(d.user_firstname, ' ', d.user_lastname, ' / ', d.user_code) as created_by, " +
                    " e.campaigntype_name" +
                    " from fnd_trn_tcampaign a left join fnd_mst_tcustomer b on a.customer_gid = b.customer_gid " +
                    " left join hrm_mst_temployee c on a.created_by = c.employee_gid" +
                    " left join adm_mst_tuser d on c.user_gid = d.user_gid " +
                    " left join fnd_mst_tcampaigntype e on a.campaigntype_gid = e.campaigntype_gid" +
                    " where campaign_gid = '" + campaign_gid +"'";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getcampaign_list = new List<campaign_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getcampaign_list.Add(new campaign_list
                    {
                        campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                        campaign_code = (dr_datarow["campaign_code"].ToString()),
                        campaign_name = (dr_datarow["campaign_name"].ToString()),
                        Status = (dr_datarow["status"].ToString()),
                        campaign_status = (dr_datarow["campaign_status"].ToString()),
                        status_flag = (dr_datarow["status_flag"].ToString()),
                        customer_name = (dr_datarow["customer_name"].ToString()),
                        created_by = (dr_datarow["created_by"].ToString()),
                        created_date = (dr_datarow["created_date"].ToString()),
                         campaigntype_name = (dr_datarow["campaigntype_name"].ToString()),
                    });
                }
                values.campaign_list = getcampaign_list;

               msSQL = " select* from fnd_trn_tmycampaignsingle where campaign_gid = '" + campaign_gid + "'";

                objODBCDatareader = objdbconn.GetDataReader(msSQL);
                if (objODBCDatareader.HasRows == true)
                { values.lsFlag = "Y"; }
                else { values.lsFlag = "N"; }
                objODBCDatareader.Close();
                
            }
            dt_datatable.Dispose();
        }
        public void DaGetMycampaignSingle(MdlTrnCampaign values, string campaign_gid, string employee_gid)
        {
            values.lsFlag = "N";
            msSQL = " select c.campaign_gid,a.campaigndtl_gid,a.questionnarie_gid, " +
                     "campaign_code,d.campaigntype_name,c.start_date,c.end_date,c.assesment_date,e.customer_name," +
                     "c.contact_name, c.contact_mobile, c.contact_email," +
                     " c.campaign_name,a.questionnarie_type,a.questionnarie_answer, " +
                     " a.questionnarie_name,f.questionnarie_answer as singleform_answer ,f.mycampaignsingle_gid,a.importance from fnd_trn_tcampaigndtl a " +
                     " left join fnd_mst_tquestionnarie b on a.questionnarie_gid = b.questionnarie_gid " +
                     " left join fnd_trn_tcampaign c on c.campaign_gid = a.campaign_gid " +
                     " left join fnd_mst_tcampaigntype d on d.campaigntype_gid = c.campaigntype_gid " +
                     " left join fnd_mst_tcustomer e on e.customer_gid = c.customer_gid " +
                     " left join fnd_trn_tmycampaignsingle f on f.questionnarie_gid = a.questionnarie_gid and f.campaign_gid =a.campaign_gid " +
                     " where a.campaign_gid='" + campaign_gid + "' and a.form_type = 'S'";
            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getcampaign_details = new List<campaign_details>();

            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {


                    var getanswerdesc_details = new List<answerdesc_list>();
                    if ((dr_datarow["questionnarie_type"].ToString() == "List"))
                    {
                        string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                        string[] ansdesc_sList = answerdesc_list.Split(',');

                        foreach (string author in ansdesc_sList)
                        {
                            getanswerdesc_details.Add(new answerdesc_list
                            {
                                name = author,

                            });
                        }

                    }
                    if ((dr_datarow["questionnarie_type"].ToString() == "Radio_Button"))
                    {
                        string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                        string[] ansdesc_sList = answerdesc_list.Split(',');

                        foreach (string author in ansdesc_sList)
                        {
                            getanswerdesc_details.Add(new answerdesc_list
                            {
                                id = (dr_datarow["questionnarie_gid"].ToString()),
                                name = author,

                            });
                        }

                    }
                    getcampaign_details.Add(new campaign_details
                    {
                        
                        campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                        campaigndtl_gid = (dr_datarow["campaigndtl_gid"].ToString()),
                        questionnarie_gid = (dr_datarow["questionnarie_gid"].ToString()),
                        answer_type = (dr_datarow["questionnarie_type"].ToString()),
                        answer_desc = (dr_datarow["questionnarie_answer"].ToString()),
                        campaign_name = (dr_datarow["campaign_name"].ToString()),
                        question = (dr_datarow["questionnarie_name"].ToString()),
                        campaignrefno = dr_datarow["campaign_code"].ToString(),
                        campaign_type = dr_datarow["campaigntype_name"].ToString(),
                        customer_name = dr_datarow["customer_name"].ToString(),
                        contactperson_fn = dr_datarow["contact_name"].ToString(),
                        contactperson_mobile = dr_datarow["contact_mobile"].ToString(),
                        contactperson_email = dr_datarow["contact_email"].ToString(),
                        start_date = dr_datarow["start_date"].ToString(),
                        end_date = dr_datarow["end_date"].ToString(),
                        assesment_date = dr_datarow["assesment_date"].ToString(),
                        singleform_answer = (dr_datarow["singleform_answer"].ToString()),
                        importance = (dr_datarow["importance"].ToString()),
                        mycampaignsingle_gid = (dr_datarow["mycampaignsingle_gid"].ToString()),
                        answerdesc_list = getanswerdesc_details,
                    });

                }
                values.campaign_details = getcampaign_details;




            }
            dt_datatable.Dispose();
            values.status = true;
            msSQL = " select* from fnd_trn_tmycampaignsingle where campaign_gid = '" + campaign_gid + "'";

            objODBCDatareader = objdbconn.GetDataReader(msSQL);
            if (objODBCDatareader.HasRows == true)
            { values.lsFlag = "Y"; }
            else { values.lsFlag = "N"; }
            objODBCDatareader.Close();


        }
        public void DaGeteditMycampaignMultiple(MdlTrnCampaign values, string campaign_gid,string reference_gid, string employee_gid)
        {
            values.lsFlag = "N";
         
            try
            {
                msSQL = " select c.campaign_gid,a.campaigndtl_gid,a.questionnarie_gid, " +
                    "campaign_code,d.campaigntype_name,c.start_date,c.end_date,c.assesment_date,e.customer_name," +
                    "c.contact_name, c.contact_mobile, c.contact_email," +
                        " c.campaign_name,a.questionnarie_type,a.questionnarie_answer, " +
                        " a.questionnarie_name,f.header_values as multipleform_answer ,f.mycampaignmultiple_gid ,a.importance from fnd_trn_tcampaigndtl a " +
                        " left join fnd_mst_tquestionnarie b on a.questionnarie_gid = b.questionnarie_gid " +
                        " left join fnd_trn_tcampaign c on c.campaign_gid = a.campaign_gid " +
                        " left join fnd_mst_tcampaigntype d on d.campaigntype_gid = c.campaigntype_gid " +
                         " left join fnd_mst_tcustomer e on e.customer_gid = c.campaigntype_gid " +
                          " left join fnd_trn_tmycampaignmultiple f on f.questionnarie_gid = a.questionnarie_gid and f.campaign_gid =a.campaign_gid " +
                     " and f.reference_gid = '" + reference_gid + "'" +
                        " where a.campaign_gid='" + campaign_gid + "' and a.form_type = 'M'";
                dt_datatable = objdbconn.GetDataTable(msSQL);
                var getmulticampaign_details = new List<multi_campaign_details>();

                if (dt_datatable.Rows.Count != 0)
                {
                    foreach (DataRow dr_datarow in dt_datatable.Rows)
                    {


                        var getmultianswerdesc_details = new List<multi_answerdesc_list>();
                        if ((dr_datarow["questionnarie_type"].ToString() == "List"))
                        {
                            string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                            string[] ansdesc_sList = answerdesc_list.Split(',');

                            foreach (string author in ansdesc_sList)
                            {
                                getmultianswerdesc_details.Add(new multi_answerdesc_list
                                {
                                    name = author,

                                });
                            }

                        }
                        if ((dr_datarow["questionnarie_type"].ToString() == "Radio_Button"))
                        {
                            string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
                            string[] ansdesc_sList = answerdesc_list.Split(',');

                            foreach (string author in ansdesc_sList)
                            {
                                getmultianswerdesc_details.Add(new multi_answerdesc_list
                                {
                                    id = (dr_datarow["questionnarie_gid"].ToString()),
                                    name = author,

                                });
                            }

                        }
                        getmulticampaign_details.Add(new multi_campaign_details
                        {
                            campaign_gid = (dr_datarow["campaign_gid"].ToString()),
                            campaigndtl_gid = (dr_datarow["campaigndtl_gid"].ToString()),
                            questionnarie_gid = (dr_datarow["questionnarie_gid"].ToString()),
                            answer_type = (dr_datarow["questionnarie_type"].ToString()),
                            answer_desc = (dr_datarow["questionnarie_answer"].ToString()),
                            campaign_name = (dr_datarow["campaign_name"].ToString()),
                            question = (dr_datarow["questionnarie_name"].ToString()),
                            campaignrefno = dr_datarow["campaign_code"].ToString(),
                            campaign_type = dr_datarow["campaigntype_name"].ToString(),
                            customer_name = dr_datarow["customer_name"].ToString(),
                            contactperson_fn = dr_datarow["contact_name"].ToString(),
                            contactperson_mobile = dr_datarow["contact_mobile"].ToString(),
                            contactperson_email = dr_datarow["contact_email"].ToString(),
                            start_date = dr_datarow["start_date"].ToString(),
                            end_date = dr_datarow["end_date"].ToString(),
                            assesment_date = dr_datarow["assesment_date"].ToString(),
                            multi_answerdesc_list = getmultianswerdesc_details,
                            multipleform_answer = dr_datarow["multipleform_answer"].ToString(),
                            mycampaignmultiple_gid = dr_datarow["mycampaignmultiple_gid"].ToString(),
                            importance = (dr_datarow["importance"].ToString()),


                        });

                    }
                    values.multi_campaign_details = getmulticampaign_details;




                }
                dt_datatable.Dispose();
                values.status = true;
            }
            catch (Exception ex)
            {
                values.status = false;
            }

        }
        public void DaGetCampaignEditDetails(MdlFndTrnMyCampaignSummary values, string campaign_gid)
        {



            //try
            //{
            //    msSQL = " select c.campaign_gid,a.campaigndtl_gid,a.questionnarie_gid, " +
            //        "campaign_code,d.campaigntype_name,c.start_date,c.end_date,c.assesment_date,e.customer_name," +
            //        "c.contact_name, c.contact_mobile, c.contact_email," +
            //            " c.campaign_name,a.questionnarie_type,a.questionnarie_answer, " +
            //            " a.questionnarie_name from fnd_trn_tmycampaignsingle c " +
            //            " where a.campaign_gid='" + campaign_gid + "' and a.form_type = 'S'";
            //    dt_datatable = objdbconn.GetDataTable(msSQL);
            //    var getcampaign_details = new List<campaign_details>();

            //    if (dt_datatable.Rows.Count != 0)
            //    {
            //        foreach (DataRow dr_datarow in dt_datatable.Rows)
            //        {


            //            var getanswerdesc_details = new List<answerdesc_list>();
            //            if ((dr_datarow["questionnarie_type"].ToString() == "List"))
            //            {
            //                string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
            //                string[] ansdesc_sList = answerdesc_list.Split(',');

            //                foreach (string author in ansdesc_sList)
            //                {
            //                    getanswerdesc_details.Add(new answerdesc_list
            //                    {
            //                        name = author,

            //                    });
            //                }

            //            }
            //            if ((dr_datarow["questionnarie_type"].ToString() == "Radio_Button"))
            //            {
            //                string answerdesc_list = dr_datarow["questionnarie_answer"].ToString();
            //                string[] ansdesc_sList = answerdesc_list.Split(',');

            //                foreach (string author in ansdesc_sList)
            //                {
            //                    getanswerdesc_details.Add(new answerdesc_list
            //                    {
            //                        id = (dr_datarow["questionnarie_gid"].ToString()),
            //                        name = author,

            //                    });
            //                }

            //            }
            //            getcampaign_details.Add(new campaign_details
            //            {
            //                campaign_gid = (dr_datarow["campaign_gid"].ToString()),
            //                campaigndtl_gid = (dr_datarow["campaigndtl_gid"].ToString()),
            //                questionnarie_gid = (dr_datarow["questionnarie_gid"].ToString()),
            //                answer_type = (dr_datarow["questionnarie_type"].ToString()),
            //                answer_desc = (dr_datarow["questionnarie_answer"].ToString()),
            //                campaign_name = (dr_datarow["campaign_name"].ToString()),
            //                question = (dr_datarow["questionnarie_name"].ToString()),
            //                campaignrefno = dr_datarow["campaign_code"].ToString(),
            //                campaign_type = dr_datarow["campaigntype_name"].ToString(),
            //                customer_name = dr_datarow["customer_name"].ToString(),
            //                contactperson_fn = dr_datarow["contact_name"].ToString(),
            //                contactperson_mobile = dr_datarow["contact_mobile"].ToString(),
            //                contactperson_email = dr_datarow["contact_email"].ToString(),
            //                start_date = dr_datarow["start_date"].ToString(),
            //                end_date = dr_datarow["end_date"].ToString(),
            //                assesment_date = dr_datarow["assesment_date"].ToString(),
            //                answerdesc_list = getanswerdesc_details,
            //            });

            //        }
            //        values.campaign_details = getcampaign_details;




            //    }
            //    dt_datatable.Dispose();
            //    values.status = true;
            //}
            //catch (Exception ex)
            //{
            //    values.status = false;
            //}
        }
        public void DaGetMycampaignMultiple(MdlFndTrnMyCampaignSummary values, string campaign_gid, string employee_gid)
        {

            msSQL = "select mycampaignmultiple_gid,questionnarie_gid," +
                    "reference_gid,header_names as questionnarie_name," +
                    " header_values as questionnarie_answer  from  fnd_trn_tmycampaignmultiple " +
                    " where campaign_gid = '" + campaign_gid + "' and created_by  in ('" + employee_gid + "') " +
                    " group by reference_gid,campaign_gid ";

           dt_datatable = objdbconn.GetDataTable(msSQL);
            var getmultipleformanswer_list = new List<multipleformanswer_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getmultipleformanswer_list.Add(new multipleformanswer_list
                    {

                        quest_Id = (dr_datarow["questionnarie_gid"].ToString()),
                        quest_name = (dr_datarow["questionnarie_name"].ToString()),
                        quest_answer = (dr_datarow["questionnarie_answer"].ToString()),
                        mycampaignmultiple_gid = (dr_datarow["mycampaignmultiple_gid"].ToString()),
                        reference_Id = (dr_datarow["reference_gid"].ToString()),

                    });
                }
                values.multipleformanswer_list = getmultipleformanswer_list;
            }
            dt_datatable.Dispose();

        }
        public void DaGetMycampaignTeamActivity(MdlFndTrnMyCampaignSummary values, string campaign_gid, string employee_gid)
        {

            msSQL = " select a.mycampaignmultiple_gid,a.questionnarie_gid," +
                    " a.reference_gid,a.header_names as questionnarie_name," +
                    " a.header_values as questionnarie_answer , concat(c.user_firstname,' ',c.user_lastname,' / ',c.user_code) as created_by " +
                    " from  fnd_trn_tmycampaignmultiple a " +
                    " left join hrm_mst_temployee b on a.created_by = b.employee_gid" +
                    " left join adm_mst_tuser c on c.user_gid = b.user_gid  " +
                    " where a.campaign_gid = '" + campaign_gid + "' and a.created_by not in ('" + employee_gid + "') " +
                    " group by a.reference_gid,a.campaign_gid ";

            dt_datatable = objdbconn.GetDataTable(msSQL);
            var getmultipleformTeamanswer_list = new List<multipleformTeamanswer_list>();
            if (dt_datatable.Rows.Count != 0)
            {
                foreach (DataRow dr_datarow in dt_datatable.Rows)
                {
                    getmultipleformTeamanswer_list.Add(new multipleformTeamanswer_list
                    {

                        quest_Id = (dr_datarow["questionnarie_gid"].ToString()),
                        quest_name = (dr_datarow["questionnarie_name"].ToString()),
                        quest_answer = (dr_datarow["questionnarie_answer"].ToString()),
                        mycampaignmultiple_gid = (dr_datarow["mycampaignmultiple_gid"].ToString()),
                        reference_Id = (dr_datarow["reference_gid"].ToString()),

                    });
                }
                values.multipleformTeamanswer_list = getmultipleformTeamanswer_list;
            }
            dt_datatable.Dispose();

        }
        public bool DaMyCampaignMultipleSubmit(MdlFndTrnMyCampaignSummary values, string employee_gid)
        {
          

            msSQL = " insert into fnd_trn_tmycampaignmultiple ( " +
                    " campaign_gid,reference_gid," +
                    " questionnarie_gid, header_names," +
                    " header_values," +
                    " created_by,created_date" +
                   "  )" +
                   " values(" +
                   "'" + values.campaign_gid + "'," +
                   "'" + values.form_type + "'," +
                   "'" + values.questionnarie_gid + "'," +
                   "'" + values.questionnarie_name + "'," +
                   "'" + values.questionnarie_answer + "'," +
                   "'" + employee_gid + "'," +
                    "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";

            mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
            if (mnResult != 0)
            {
                msSQL = " update fnd_mst_tcampaignapproving2employee set mycampaign_status = 'Pending for Final Approval' " +
                        " where campaign_gid='" + values.campaign_gid + "' and employee_gid = '" + employee_gid + "'";
                mnResult = objdbconn.ExecuteNonQuerySQL(msSQL);
                

                values.status = true;
                values.message = "Multiple Form Added Successfully";


                return true;
            }
            else
            {
                values.status = false;
                values.message = "Error Occured While Saving Multiple Form";
                return false;
            }

        }
    }
}
